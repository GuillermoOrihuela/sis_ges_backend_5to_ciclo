from django.apps import AppConfig


class InformesConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.informes"
    verbose_name = "Informes"
